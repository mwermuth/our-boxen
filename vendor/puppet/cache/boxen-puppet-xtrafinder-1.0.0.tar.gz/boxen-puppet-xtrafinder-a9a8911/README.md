# XtraFinder Puppet Module for Boxen

Install [XtraFinder](http://www.trankynam.com/xtrafinder/), a tool that adds Tabs and features to Mac Finder.

## Usage

```puppet
include xtrafinder
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run one of the following tasks to test it:
* `rake syntax`
* `rake style`
* `rake spec`
* `rake build`
